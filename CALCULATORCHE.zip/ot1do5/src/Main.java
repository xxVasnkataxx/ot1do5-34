import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Въведете първо цяло число: ");
        int num1 = input.nextInt();

        System.out.print("Въведете второ цяло число: ");
        int num2 = input.nextInt();

        // Сума
        int sum = num1 + num2;
        System.out.println("Сумата на числата е: " + sum);

        // Разлика
        int difference = num1 - num2;
        System.out.println("Разликата между първото и второто число е: " + difference);

        // Произведение
        int product = num1 * num2;
        System.out.println("Произведението на числата е: " + product);

        // Целочислено деление
        if (num2 != 0) {
            int division = num1 / num2;
            System.out.println("Целочисленото деление на първото число на второто число е: " + division);

            // Остатък при деление
            int remainder = num1 % num2;
            System.out.println("Остатъка при деление на първото число на второто число е: " + remainder);
        } else {
            System.out.println("Второто число не може да бъде нула за деление.");
        }

        input.close();
    }
}

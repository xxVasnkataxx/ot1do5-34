public class Main {
    public static void main(String[] args) {

        System.out.println("Hello Java!");
        System.out.println("This is another line");

        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");

        System.out.println("1 2 3 4 5");
        System.out.println("1 2 3 4 5");
        System.out.println("1 2 3 4 5");

    }
}